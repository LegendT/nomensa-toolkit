---
title: Colors
---
Colors below are automatically pulled from `_color-vars.scss` if they are prefixed with `$c-` and can be used like so:

```scss
.class {
  color: $c-red;
}
```
