---
title: Headings
---

All heading styles can be attained by a few methods; for example, Header 2 styling can be given by using an element (`<h2>), a class (`.h2`), or a Sass mixin (`@include h2()`).
